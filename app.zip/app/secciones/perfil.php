<?php 
include('../templates/header.php');?>

<div class="col-md-8">
    <br>
<div class="card">
<div class="card-header">
<h5>Información de la cuenta</h5>
</div>
<div class="card-body">
    <label for="" class="form-label">ID Supervisor</label>
    <input type="number"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="#####">

    <label for="" class="form-label">Nombre(s)</label>
    <input type="text"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="nombre(s)">


    <label for="" class="form-label">Apellido paterno</label>
    <input type="text"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="apellido paterno">

    <label for="" class="form-label">Apellido materno</label>
    <input type="text"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="apellido materno">

    <label for="" class="form-label">Dirección de correo electrónico</label>
    <input type="text"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="email">

    <form action="" method="">
    <br>
    <button type="submit" class="btn btn-primary btn-md" onclick="saveInfo()">Guardar cambios</button>
    </form>
</div>
</div>
</div>
<script>
    function saveInfo(){
        var opcion=confirm("¿Desea guardar la información?");
        if(opcion==true){
            alert("Información registrada con éxito!");
        }
    }
</script>
<?php
include('../templates/footer.php');?>