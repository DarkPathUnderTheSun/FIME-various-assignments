<?php 
include('../templates/header.php');?>
<div>
<br>
<h3>Generar orden de trabajo</h3>
</div>
<div class="col-md-4">
    <br>
    <label for="" class="form-label">Fecha registro:</label>
    <input type="date"></input>
</div>

<div class="col-md-4">
    <br>
    <label for="" class="form-label">Fecha vencimiento:</label>
    <input type="date"></input>
</div>

<div class="col-md-4">
    <br>
    <label for="" class="form-label">Fecha pago:</label>
    <input type="date"></input>
</div>

<div class="col-md-4">
    <br>
    <label for="" class="form-label">ID Orden de Trabajo</label>
    <input type="number"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="">
</div>

<div class="col-md-4">
    <br>
    <label for="" class="form-label">Técnico</label>
    <input type="text"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="">
</div>

<div class="col-md-4">
    <br>
    <label for="" class="form-label">Cliente</label>
    <input type="text"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="">
</div>

<div class="col-md-4">
    <br>
    <label for="" class="form-label">Ubicación</label>
    <input type="text"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="">
</div>

<div class="col-md-4">
    <br>
    <label for="" class="form-label">Costo $</label>
    <input type="number"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="">
</div>

<div class="col-md-4">
    <br>
    <label for="" class="form-label">Prioridad</label>
    <select for="" class="form-select">
        <option selected>Seleccione una opción</option>
        <option value="1">Alta</option>
        <option value="2">Media</option>
        <option value="3">Baja</option> 
    </select>
</div>

<div class="col-md-12">
    <br>
    <label for="" class="form-label">Descripción del trabajo</label>
    <input type="text"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="">
</div>

<div class="col-md-4">
    <br>
    <button class="btn btn-success" onclick="guardar()">Guardar</button>
    <button class="btn btn-info" onclick="editar()">Editar</button>
    <button class="btn btn-danger" onclick="eliminar()">Eliminar</button>
</div>

<script>
    function guardar(){
        var opcion=confirm("¿Desea guardar la información?");
        if(opcion==true){
            alert("Información registrada con éxito!");
        }
    }

    function editar(){
        
    }

    function eliminar(){
        var opcion=confirm("¿Estás seguro de eliminar este registro?");
        if(opcion==true){
            alert("Registro eliminado con éxito!");
        }
    }
</script>
<?php
include('../templates/footer.php');?>