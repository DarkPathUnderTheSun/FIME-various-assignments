<?php 
include('../templates/header.php');?>
<div class="col-md-5">
    <br>
<div class="card">    
<div class="card-header">
<h4>Administrador de órdenes de trabajo</h4>
</div>
<div class="card-body">
<div class="mb-3">
    <label for="" class="form-label">ID Orden de trabajo</label>
    <input type="number"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="id">

    <label for="" class="form-label">Cliente</label>
    <input type="text"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="cliente">

    <label for="" class="form-label">Técnico</label>
    <input type="text"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="agente">

    <br>
    <button type="submit" class="btn btn-primary btn-md">Buscar</button>
</div>
</div>
</div>
</div>

<div class="col-md-7">
    <br>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">CLIENTE</th>
                    <th scope="col">UBICACIÓN</th>
                    <th scope="col">COSTO $</th>
                    <th scope="col">TÉCNICO ASIGNADO</th>
                </tr>
            </thead>
            <tbody>
                <tr class="">
                    <td scope="row">12345</td>
                    <td>Prueba</td>
                    <td>Prueba</td>
                    <td>500.00</td>
                    <td>Prueba</td>
                </tr>
            </tbody>
        </table>
    </div>
    
</div>


<?php
include('../templates/footer.php');?>