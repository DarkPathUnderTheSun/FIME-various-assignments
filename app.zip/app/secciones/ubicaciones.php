<?php 
include('../templates/header.php');?>

<div>
<br>
<h3>Ubicaciones de trabajo</h3>
</div>

<div class="col-md-4">
    <br>
    <label for="" class="form-label">ID Cliente</label>
    <input type="number"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="">
</div>

<div class="col-md-8">
    <br>
    <label for="" class="form-label">Cliente</label>
    <input type="text"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="" readonly>
</div>

<div class="col-md-4">
    <br>
    <label for="" class="form-label">ID Ubicación</label>
    <input type="number"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="">
</div>

<div class="col-md-4">
    <br>
    <label for="" class="form-label">Nombre</label>
    <input type="text"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="">
</div>

<div class="col-md-4">
    <br>
    <label for="" class="form-label">Dirección</label>
    <input type="text"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="">
</div>

<div class="col-md-4">
    <br>
    <label for="" class="form-label">Colonia</label>
    <input type="text"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="">
</div>

<div class="col-md-4">
    <br>
    <label for="" class="form-label">País</label>
    <input type="text"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="">
</div>

<div class="col-md-4">
    <br>
    <label for="" class="form-label">Estado</label>
    <input type="text"
    class="form-control" name="" id="" aria-describedby="helpId" placeholder="">
</div>

<div class="col-md-8">
    <br>
    <button class="btn btn-success" onclick="guardar()">Guardar</button>
    <button class="btn btn-danger" onclick="eliminar()">Eliminar</button>
</div>

<script>
    function guardar(){
        alert("Información registrada con éxito!");
    }

    function eliminar(){
        var opcion = confirm("¿Está seguro de eliminar el registro?");
        if(opcion==true){
            alert("Registro eliminado con éxito!");
        }
    }
</script>

<?php
include('../templates/footer.php');?>