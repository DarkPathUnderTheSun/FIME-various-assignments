<!doctype html>
<html lang="en">

<head>
  <title>Dispositivos Móviles</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

</head>
<body>
<nav class="navbar navbar-expand " style="background-color: #e3f2fd;">
<div class="container-fluid">
    <a class="nav navbar-brand" href="index.php">Logo</a>
    <div class="collapse navbar-collapse">
    <div class="nav navbar-nav">
    <a class="nav-item nav-link active" href="index.php">Inicio</a>
    <div class="collapse navbar-collapse">
    <ul class="navbar-nav">
    <li class="nav-item dropdown">    
    <a role="button" class="nav-link dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">Catálogos</a>
    <ul class="dropdown-menu">
        <li><a class="dropdown-item" href="clientes.php">Clientes</a></li>
        <li><a class="dropdown-item" href="ubicaciones.php">Ubicaciones</a></li>  
    </ul>
    </li>
    </ul>
    </div>
    <div class="collapse navbar-collapse">
    <ul class="navbar-nav">
    <li class="nav-item dropdown">    
    <a role="button" class="nav-link dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">Orden de Trabajo</a>
    <ul class="dropdown-menu">
        <li><a class="dropdown-item" href="ot.php">Generar OT</a></li>
        <li><a class="dropdown-item" href="adminOT.php">Administrador OT</a></li>
    </ul>
    </li>
    </ul>
    </div>
    <div class="collapse navbar-collapse">
    <ul class="navbar-nav">
    <li class="nav-item dropdown">    
    <a role="button" class="nav-link dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">Sesión</a>
    <ul class="dropdown-menu">
        <li><a class="dropdown-item" href="perfil.php">Modificar Perfil</a></li>
        <li><a class="dropdown-item" href="#" onclick="cerrar()">Cerrar sesión</a></li>
    </ul>
    </li>
    </ul>
    </div>
    </div>
</div>
<form class="d-flex" role="search">
      <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success" type="submit">Search</button>
    </form>
</nav>
 
<script>
    function cerrar() {
        var opcion=confirm("¿Desea cerrar sesión?");
        if(opcion==true){
            window.location.href = '/app/index.php';
        }else{
            
        }
    }
</script>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="row">
               